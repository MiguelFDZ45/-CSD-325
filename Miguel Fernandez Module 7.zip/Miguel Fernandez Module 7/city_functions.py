def city_country(city, country, population=None, language=None):

    result = f"{city}, {country}"
    if population:
        result += f" - Population: {population}"
    if language:
        result += f" - Language: {language}"
    return result

print(city_country("Santiago", "Chile"))
print(city_country("Cordoba", "Argentina", population=8000000))
print(city_country("Caracas", "Venezuela", population=120000, language="Spanish"))