#Miguel Fernandez
#Module 8
import json

#Load The Json file
with open("student.json", "r") as file:
    class_list = json.load(file)

#Print the student list
def print_student_list(students, notification):
    print(notification)
    for student in students:
        print(f'{student["L_Name"]}, {student["F_Name"]} : ID = {student["Student_ID"]} , Email = {student["Email"]}')
    print()

# Print Original List
print_student_list(class_list, "Original List:")

# add new student
new_student = {
    "F_Name": "Miguel",
    "L_Name": "Fernandez",
    "Student_ID": 894,
    "Email": "mfernd@yahoo.com"
}
class_list.append(new_student)

#Print New list
print_student_list(class_list, "Updated Student List:")

# Write the list to json
with open("student.json", "w") as file:
    json.dump(class_list, file, indent=4)

print("file has been updated.")